<?php
require_once 'Room.php';

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$bookingId = $_GET['id'];
$roomManager = new Room($pdo);
$booking = $roomManager->getBookingById($bookingId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userName = $_POST['user_name'];
    $startTime = $_POST['start_time'];
    $endTime = $_POST['end_time'];

    $roomManager->updateBooking($bookingId, $booking['room_id'], $userName, $startTime, $endTime);

    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edytuj rezerwację</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Edytuj rezerwację</h1>
        <form method="POST">
            <label for="user_name">Imię i nazwisko:</label>
            <input type="text" id="user_name" name="user_name" value="<?= htmlspecialchars($booking['user_name']) ?>" required>
            <br>
            <label for="start_time">Data i godzina rozpoczęcia:</label>
            <input type="datetime-local" id="start_time" name="start_time" value="<?= htmlspecialchars(str_replace(' ', 'T', $booking['start_time'])) ?>" required>
            <br>
            <label for="end_time">Data i godzina zakończenia:</label>
            <input type="datetime-local" id="end_time" name="end_time" value="<?= htmlspecialchars(str_replace(' ', 'T', $booking['end_time'])) ?>" required>
            <br>
            <button type="submit" class="btn">Zapisz zmiany</button>
        </form>
        <a href="index.php" class="btn">Powrót do listy sal</a>
    </div>
</body>
</html>