<?php
require_once 'Room.php';

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$bookingId = $_GET['id'];
$roomManager = new Room($pdo);
$roomManager->deleteBooking($bookingId);

header('Location: index.php');
exit;
?>