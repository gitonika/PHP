<?php
require_once 'db.php';

class Room {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Pobierz listę wszystkich sal
    public function getAllRooms() {
        $stmt = $this->pdo->query("SELECT * FROM rooms");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Pobierz rezerwacje dla konkretnej sali
    public function getBookingsByRoomId($roomId) {
        $stmt = $this->pdo->prepare("SELECT * FROM bookings WHERE room_id = :room_id ORDER BY start_time");
        $stmt->execute(['room_id' => $roomId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Dodaj nową rezerwację
    public function addBooking($roomId, $userName, $startTime, $endTime) {
        $stmt = $this->pdo->prepare("INSERT INTO bookings (room_id, user_name, start_time, end_time) VALUES (:room_id, :user_name, :start_time, :end_time)");
        $stmt->execute([
            'room_id' => $roomId,
            'user_name' => $userName,
            'start_time' => $startTime,
            'end_time' => $endTime
        ]);
    }

    // Pobierz rezerwację po ID
    public function getBookingById($bookingId) {
        $stmt = $this->pdo->prepare("SELECT * FROM bookings WHERE id = :id");
        $stmt->execute(['id' => $bookingId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Edytuj rezerwację
    public function updateBooking($bookingId, $roomId, $userName, $startTime, $endTime) {
        $stmt = $this->pdo->prepare("UPDATE bookings SET room_id = :room_id, user_name = :user_name, start_time = :start_time, end_time = :end_time WHERE id = :id");
        $stmt->execute([
            'id' => $bookingId,
            'room_id' => $roomId,
            'user_name' => $userName,
            'start_time' => $startTime,
            'end_time' => $endTime
        ]);
    }

    // Usuń rezerwację
    public function deleteBooking($bookingId) {
        $stmt = $this->pdo->prepare("DELETE FROM bookings WHERE id = :id");
        $stmt->execute(['id' => $bookingId]);
    }
}
?>