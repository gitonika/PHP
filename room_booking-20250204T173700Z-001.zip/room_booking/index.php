<?php
require_once 'Room.php';

$roomManager = new Room($pdo);
$rooms = $roomManager->getAllRooms();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System rezerwacji sal</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>System rezerwacji sal</h1>
        <?php foreach ($rooms as $room): ?>
            <h2><?= htmlspecialchars($room['name']) ?> (Pojemność: <?= $room['capacity'] ?> osób)</h2>
            <a href="add_booking.php?room_id=<?= $room['id'] ?>" class="btn">Zarezerwuj tę salę</a>
            <h3>Rezerwacje:</h3>
            <ul>
                <?php
                $bookings = $roomManager->getBookingsByRoomId($room['id']);
                foreach ($bookings as $booking):
                ?>
                    <li>
                        <strong><?= htmlspecialchars($booking['user_name']) ?></strong>
                        <p>Od: <?= htmlspecialchars($booking['start_time']) ?></p>
                        <p>Do: <?= htmlspecialchars($booking['end_time']) ?></p>
                        <div>
                            <a href="edit_booking.php?id=<?= $booking['id'] ?>">Edytuj</a>
                            <a href="delete_booking.php?id=<?= $booking['id'] ?>" onclick="return confirm('Czy na pewno chcesz usunąć tę rezerwację?')">Usuń</a>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endforeach; ?>
    </div>
</body>
</html>